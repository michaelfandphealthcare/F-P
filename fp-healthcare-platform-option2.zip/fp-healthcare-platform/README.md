# F&P Healthcare Full-Stack Platform

A polished, responsive healthcare website and operational portal prototype for F&P Healthcare. It reflects the company's public service positioning: workforce solutions, training, care services and consultancy.

## Included

- Responsive public website
- Services, employers, training, about and contact pages
- Searchable healthcare jobs
- Working online job application workflow
- Working employer/contact enquiry workflow
- JWT login with admin, staff and client demo accounts
- Operational dashboard with live API data
- Backend validation, security headers and role checks
- JSON persistence for a simple zero-database local setup
- Production build scripts

## Run locally

Requirements: Node.js 20+

```bash
cd fp-healthcare-platform
npm install
npm run install:all
cp server/.env.example server/.env
cp client/.env.example client/.env
npm run dev
```

Open `http://localhost:5173`.

API: `http://localhost:4000/api`

## Demo portal accounts

All use password: `password`

- `admin@fphealthcare.test`
- `staff@fphealthcare.test`
- `client@fphealthcare.test`

## Production deployment

1. Build the frontend with `npm run build`.
2. Deploy `client/dist` to a static host or CDN.
3. Deploy the Express API to a Node.js host.
4. Set `JWT_SECRET` to a long random secret and `CLIENT_ORIGIN` to the live frontend URL.
5. Replace the JSON store with PostgreSQL before handling sensitive or high-volume production data.
6. Add an approved email/SMS provider for transactional notifications.
7. Add secure object storage and malware scanning before enabling CV/document uploads.
8. Complete DPIA, privacy, retention, accessibility and penetration-testing work before processing real health or workforce records.

## Important content note

Public contact and company details should be verified by F&P Healthcare before launch. Illustrative statistics, testimonials, jobs and dashboard data are clearly demo content and must be replaced with approved business data.
