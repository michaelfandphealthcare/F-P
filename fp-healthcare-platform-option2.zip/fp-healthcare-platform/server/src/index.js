import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { readDb, writeDb, id } from './store.js';
import { requireAuth, requireRole, signUser } from './auth.js';

const app = express();
app.use(helmet());
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',') || true}));
app.use(express.json({limit:'2mb'}));
app.use(morgan('dev'));

app.get('/api/health',(_req,res)=>res.json({status:'ok',service:'F&P Healthcare API'}));
app.post('/api/auth/login', async (req,res)=>{
  const parsed=z.object({email:z.string().email(),password:z.string().min(6)}).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({message:'Enter a valid email and password'});
  const db=readDb(); const user=db.users.find(u=>u.email.toLowerCase()===parsed.data.email.toLowerCase());
  if(!user || !(await bcrypt.compare(parsed.data.password,user.passwordHash))) return res.status(401).json({message:'Incorrect email or password'});
  res.json({token:signUser(user), user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});
app.get('/api/jobs',(req,res)=>{
  const db=readDb(); const q=(req.query.q||'').toLowerCase(); const location=(req.query.location||'').toLowerCase(); const category=(req.query.category||'').toLowerCase();
  res.json(db.jobs.filter(j=>(!q||`${j.title} ${j.summary}`.toLowerCase().includes(q))&&(!location||j.location.toLowerCase().includes(location))&&(!category||j.category.toLowerCase().includes(category))));
});
app.get('/api/jobs/:id',(req,res)=>{ const job=readDb().jobs.find(j=>j.id===req.params.id); job?res.json(job):res.status(404).json({message:'Job not found'}); });
app.post('/api/applications',(req,res)=>{
  const schema=z.object({jobId:z.string(),name:z.string().min(2),email:z.string().email(),phone:z.string().min(7),message:z.string().max(2000).optional().default('')});
  const p=schema.safeParse(req.body); if(!p.success) return res.status(400).json({message:'Please complete all required fields'});
  const db=readDb(); if(!db.jobs.some(j=>j.id===p.data.jobId)) return res.status(404).json({message:'Job not found'});
  const application={id:id('app'),...p.data,status:'Received',createdAt:new Date().toISOString()}; db.applications.unshift(application); writeDb(db); res.status(201).json(application);
});
app.post('/api/enquiries',(req,res)=>{
  const schema=z.object({name:z.string().min(2),email:z.string().email(),phone:z.string().optional().default(''),organisation:z.string().optional().default(''),service:z.string().min(2),message:z.string().min(10)});
  const p=schema.safeParse(req.body); if(!p.success) return res.status(400).json({message:'Please complete the enquiry form'});
  const db=readDb(); const enquiry={id:id('enq'),...p.data,status:'New',createdAt:new Date().toISOString()}; db.enquiries.unshift(enquiry); writeDb(db); res.status(201).json(enquiry);
});
app.get('/api/dashboard',requireAuth,(req,res)=>{
  const db=readDb(); res.json({metrics:{activeStaff:2345,filledShifts:1089,totalBookings:1246,compliance:92,revenue:'£312,540'},bookings:db.bookings,applications:db.applications.slice(0,6),enquiries:db.enquiries.slice(0,6)});
});
app.get('/api/admin/applications',requireAuth,requireRole('admin'),(_req,res)=>res.json(readDb().applications));
app.patch('/api/admin/applications/:id',requireAuth,requireRole('admin'),(req,res)=>{
  const db=readDb(); const item=db.applications.find(a=>a.id===req.params.id); if(!item) return res.status(404).json({message:'Application not found'}); item.status=req.body.status||item.status; writeDb(db); res.json(item);
});
app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({message:'Unexpected server error'}); });
const port=Number(process.env.PORT||4000); app.listen(port,()=>console.log(`API running on http://localhost:${port}`));
