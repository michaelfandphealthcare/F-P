import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '..', 'data', 'db.json');
export function readDb(){ return JSON.parse(fs.readFileSync(dbPath,'utf8')); }
export function writeDb(data){ fs.writeFileSync(dbPath, JSON.stringify(data,null,2)); }
export function id(prefix){ return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`; }
