import jwt from 'jsonwebtoken';
const secret = process.env.JWT_SECRET || 'development-only-secret-change-me';
export function signUser(user){ return jwt.sign({sub:user.id, role:user.role, name:user.name, email:user.email}, secret, {expiresIn:'8h'}); }
export function requireAuth(req,res,next){
  const token = req.headers.authorization?.replace('Bearer ','');
  if(!token) return res.status(401).json({message:'Authentication required'});
  try { req.user = jwt.verify(token, secret); next(); }
  catch { return res.status(401).json({message:'Session expired or invalid'}); }
}
export function requireRole(...roles){ return (req,res,next)=> roles.includes(req.user?.role) ? next() : res.status(403).json({message:'You do not have permission for this action'}); }
