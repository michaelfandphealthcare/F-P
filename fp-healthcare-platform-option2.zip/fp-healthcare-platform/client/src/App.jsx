import {Routes,Route,Navigate} from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Services from './pages/Services';
import Jobs from './pages/Jobs';
import Employers from './pages/Employers';
import Training from './pages/Training';
import About from './pages/About';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
function Protected({children}){return localStorage.getItem('fp_token')?children:<Navigate to="/login" replace/>}
export default function App(){return <Routes><Route element={<Layout/>}><Route index element={<Home/>}/><Route path="services" element={<Services/>}/><Route path="jobs" element={<Jobs/>}/><Route path="employers" element={<Employers/>}/><Route path="training" element={<Training/>}/><Route path="about" element={<About/>}/><Route path="contact" element={<Contact/>}/><Route path="login" element={<Login/>}/><Route path="dashboard" element={<Protected><Dashboard/></Protected>}/><Route path="*" element={<Navigate to="/" replace/>}/></Route></Routes>}
