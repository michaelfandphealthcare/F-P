import {Link} from 'react-router-dom';
export function SectionTitle({eyebrow,title,text,center=false}){return <div className={`section-title ${center?'center':''}`}><span>{eyebrow}</span><h2>{title}</h2>{text&&<p>{text}</p>}</div>}
export function Button({to,children,secondary=false}){return <Link className={`btn ${secondary?'secondary':''}`} to={to}>{children}</Link>}
export function Toast({message,type='success'}){return message?<div className={`toast ${type}`}>{message}</div>:null}
