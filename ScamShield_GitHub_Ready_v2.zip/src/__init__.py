"""ScamShield application package."""
